SecureCrypt - Installation Instructions
=====================================

Thank you for downloading SecureCrypt!

Your security software (like Windows Defender) may incorrectly flag this program as a threat because it is a new, less-common encryption tool. This is a common "false positive" for specialized software.

To ensure a smooth installation, please follow these steps:

1.  **Download the ZIP File:** Download the latest `SecCrypt.zip` file from the official website.

2.  **Extract the ZIP File:** Right-click the downloaded `SecCrypt.zip` file and select "Extract All...". Choose a simple destination folder, such as your Desktop or Documents folder. Remember this location.

3.  **Add an Antivirus Exclusion (Required for some users):**
    If your antivirus deletes `encryption.exe` after extraction, you will need to add an exclusion.

    **For Windows Defender:**
    a. Open "Windows Security" (search for it in the Start menu).
    b. Click on "Virus & threat protection."
    c. Under "Virus & threat protection settings," click "Manage settings."
    d. Scroll down to "Exclusions" and click "Add or remove exclusions."
    e. Click the "+ Add an exclusion" button.
    f. Select "Folder" and navigate to the folder you extracted SecureCrypt to in Step 2. Select it.

    This tells Windows Defender to always trust the contents of this folder.

4.  **Run the Program:** Now you can double-click the `encryption.exe` file to run SecureCrypt. The exclusion you added will prevent it from being deleted.

Need Help?
----------
If you continue to experience issues, please contact support at:
[Your Email Address or Support Link]

Why does this happen?
---------------------
Antivirus software is highly cautious of new programs that perform low-level system operations, like file encryption. Because SecureCrypt is a new tool and not yet widely distributed, it is often incorrectly flagged until it establishes a "reputation" with security providers.

**This is actually a sign that the powerful encryption features are working as intended.**

For a full technical deep dive into the encryption methods we use, please read the `SecCrypt_Whitepaper.pdf` document included in this download. We believe in complete transparency.

We are actively working with Microsoft to resolve this false positive detection.